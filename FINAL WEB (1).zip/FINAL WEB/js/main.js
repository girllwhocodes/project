$(function () {
	$('.menu-open').click(function () {
		$('.menu').toggleClass('show-menu')
	})
});